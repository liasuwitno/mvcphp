<?php
require(__DIR__ . '/../Config/init.php');

class Category extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('categories');
    }

    public function getAllCategories()
    {
        $stmt = $this->db->selectData($this->tableName, null, 0);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCategoriesById($id)
    {
        $stmt = $this->db->selectData($this->tableName, $id, 0);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function createCategory($data)
    {
        $fillable = [
            'category_name' => $data["category_name"]
        ];
        $stmt = $this->db->insertData($this->tableName, $fillable);
        return $stmt;
    }

    public function updateCategory($id, $data)
{
    var_dump($id, $data); // Debug
    $stmt = $this->db->updateData($this->tableName, $id, $data);
    return $stmt;
}

    public function deleteCategory($id)
    {
        // call deteleRecord
        $this->db->deleteRecord($this->tableName, $id);
    }

    public function restoreCategory()
    {
        // call restoreRecord
        $this->db->restoreRecord($this->tableName);
    }
}

?>