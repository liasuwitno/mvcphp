<?php
require_once(__DIR__ . '/Config/init.php');

$categoryController = new CategoryController;

$categories = $categoryController->index();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Produk di Marketplace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-success">Category List</h2>
            <div>
                <a href="index.php" class="btn btn-secondary me-2">Back to Product List</a>
                <a href="view/categorycrud/createCategory.php" class="btn btn-success">Add Category</a>
            </div>
        </div>

        <table class="table table-bordered table-striped table-hover text-center">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Category</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($categories)) : ?>
                    <?php $counter = 1; ?>
                    <?php foreach ($categories as $category) : ?>
                        <tr>
                            <td><?php echo $counter; ?></td>
                            <td><?php echo $category["category_name"]; ?></td>
                            <td>
                                <a href="view/categorycrud/updateCategory.php?id=<?php echo $category["id"]; ?>" class="btn btn-warning btn-sm">Update</a>
                                <a href="view/categorycrud/deleteCategory.php?id=<?php echo $category["id"]; ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                        <?php $counter++; ?>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="3" class="text-center text-danger">0 results</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
