<?php
require_once(__DIR__ . '../../Config/init.php');

$id = $_GET['id'];

$productController = new ProductController();
$product = $productController->show($id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <!-- Header Section -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Product Details</h2>
            <a href="../index.php" class="btn btn-secondary">Back to Product List</a>
        </div>

        <!-- Product Details Table -->
        <table class="table table-striped table-bordered bg-white">
            <tbody>
                <tr>
                    <th scope="row" class="w-25">ID</th>
                    <td><?php echo $product["id"]; ?></td>
                </tr>
                <tr>
                    <th scope="row">Product Name</th>
                    <td><?php echo $product["product_name"]; ?></td>
                </tr>
                <tr>
                    <th scope="row">Category</th>
                    <td><?php echo $product["category_name"]; ?></td>
                </tr>
                <tr>
                    <th scope="row">Price</th>
                    <td>$<?php echo number_format($product["price"], 2); ?></td>
                </tr>
                <tr>
                    <th scope="row">Quantity</th>
                    <td><?php echo $product["stock"]; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
