<?php
require_once(__DIR__ . '/../../Config/init.php');

$id = $_GET['id'];

$categoryController = new CategoryController();
$category = $categoryController->show($id);


$errors = [];


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //validate product_name
    if (empty($_POST["category_name"])) {
        $errors['category_name'] = "Category Name is required";
    } else {
        $category_name = $_POST["category_name"];
    }
    // If there are no validation errors, proceed with updating the product
    if (empty($errors)) {
        $data = [
            'category_name' => $category_name
        ];
        if ($categoryController->update($id, $data)) {
            header("Location: ../../category.php");
        } else {
            echo "Error";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Category</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <h2 class="fw-bold mb-4">Update Category</h2>
        <a href="../../category.php" class="btn btn-secondary mb-4">Back to Category List</a>
        <?php if (!empty($category)) : ?>
            <form action="" method="post" class="bg-white p-4 rounded shadow-sm">
                <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                <div class="mb-3">
                    <label for="category_name" class="form-label">Category Name</label>
                    <input type="text" id="category_name" name="category_name" class="form-control" 
                        value="<?php echo htmlspecialchars($category['category_name']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Category</button>
            </form>
        <?php else : ?>
            <p class="text-danger">Data not found!</p>
        <?php endif ?>
    </div>
</body>

</html>
