<?php
require_once(__DIR__ . '/../../Config/init.php');

$id = $_GET['id'];

$categoryController = new CategoryController();
$category = $categoryController->show($id);
// Proses penghapusan kategori
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($categoryController->destroy($id)) {
        echo "<script>alert('Category deleted successfully!');</script>";
        header("Location: ../../category.php");
        exit();
    } else {
        echo "<script>alert('Failed to delete category!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Category</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <h2 class="fw-bold mb-4">Delete Category</h2>
        <a href="../../category.php" class="btn btn-secondary mb-4">Back to Category List</a>
        <?php if ($category) : ?>
            <p>Are you sure you want to delete the following category?</p>
            <table class="table table-bordered mt-3">
                <tr>
                    <th>ID</th>
                    <td><?php echo $category["id"]; ?></td>
                </tr>
                <tr>
                    <th>Category Name</th>
                    <td><?php echo $category["category_name"]; ?></td>
                </tr>
            </table>
            <form action="" method="post" class="mt-3">
                <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                <button type="submit" class="btn btn-danger">Delete Category</button>
            </form>
        <?php else : ?>
            <p class="text-danger">Data not found!</p>
        <?php endif ?>
    </div>
</body>

</html>
