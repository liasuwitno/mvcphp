<?php
require_once(__DIR__ . '/../../Config/init.php');

$categoryController = new CategoryController();

$error = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (empty($_POST["category_name"])) {
        $errors['category_name'] = "Category Name is required";
    } else {
        $data = ['category_name' => $_POST['category_name']];
    }
    // If there are no validation errors, proceed with creating the product
    if (empty($errors)) {
        if ($categoryController->create($data)) {
            echo "<script>alert('Category added successfully!')</script>";
            header("Location: ../../category.php");
            exit();
        } else {
            echo "<script>alert('Failed to add product!')</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Category</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <h2 class="fw-bold mb-4">Add New Category</h2>
        <a href="../../category.php" class="btn btn-secondary mb-4">Back to Category List</a>
        <form method="POST" action="" class="bg-white p-4 rounded shadow-sm">
            <div class="mb-3">
                <label for="category_name" class="form-label">Category Name</label>
                <input type="text" id="category_name" name="category_name" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Category</button>
        </form>
    </div>
</body>

</html>
