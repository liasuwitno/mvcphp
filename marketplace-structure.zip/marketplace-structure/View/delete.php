<?php
require_once(__DIR__ . '/../Config/init.php');


$id = $_GET['id'];

$productController = new ProductController();
$products = $productController->show($id);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($productController->destroy($id)) {
        echo "<script>alert('Product deleted successfully!');</script>";
        header("Location: ../index.php");
        exit();
    } else {
        echo "<script>alert('Failed to delete product!');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <!-- Header Section -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-danger">Delete Product</h2>
            <a href="../index.php" class="btn btn-secondary">Back to Product List</a>
        </div>

        <?php if ($products) : ?>
            <p class="text-danger">Are you sure you want to delete the following product?</p>
            
            <!-- Product Details Table -->
            <table class="table table-bordered bg-white">
                <tbody>
                    <tr>
                        <th>ID</th>
                        <td><?php echo $products["id"]; ?></td>
                    </tr>
                    <tr>
                        <th>Product Name</th>
                        <td><?php echo $products["product_name"]; ?></td>
                    </tr>
                    <tr>
                        <th>Category</th>
                        <td><?php echo $products["category_name"]; ?></td>
                    </tr>
                    <tr>
                        <th>Price</th>
                        <td>$<?php echo $products["price"]; ?></td>
                    </tr>
                    <tr>
                        <th>Quantity</th>
                        <td><?php echo $products["stock"]; ?></td>
                    </tr>
                </tbody>
            </table>

            <!-- Confirmation Form -->
            <form action="" method="POST" class="text-end">
                <input type="hidden" name="id" value="<?php echo $products['id']; ?>">
                <button type="submit" class="btn btn-danger">Delete Product</button>
            </form>
        <?php else : ?>
            <!-- No Data Found -->
            <div class="alert alert-warning text-center" role="alert">
                Data not found!
            </div>
        <?php endif ?>
    </div>
</body>
</html>
