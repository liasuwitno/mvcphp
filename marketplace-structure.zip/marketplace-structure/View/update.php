<?php
require_once(__DIR__ . '../../Config/init.php');

$id = $_GET['id'];

$productController = new ProductController();
$products = $productController->show($id);

$categoryController = new CategoryController();
$categories = $categoryController->index();
$errors = []; // Ambil kategori dari database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate product_name
    if (empty($_POST["product_name"])) {
        $errors['product_name'] = "Product Name is required";
    } else {
        $product_name = $_POST["product_name"];
    }

    // Validate price
    if (empty($_POST["price"])) {
        $errors['price'] = "Price is required";
    } else if (!is_numeric($_POST["price"])) {
        $errors['price'] = "Price must be a number";
    } else if (floatval($_POST["price"]) <= 0) {
        $errors['price'] = "Price should be greater than zero";
    } else {
        $price = $_POST["price"];
    }

    // Validate stock
    if (!isset($_POST["stock"]) || empty($_POST["stock"])) {
        $errors['stock'] = "stock is required";
    } else if (!is_numeric($_POST["stock"])) {
        $errors['stock'] = "stock must be a valid number";
    } else if ((int)$_POST["stock"] < 0) {
        $errors['stock'] = "stock cannot be negative";
    } else {
        $stock = (int)$_POST["stock"];
    }

    // Validate category_id
    if (!empty($_POST["category_id"]) && is_numeric($_POST["category_id"])) {
        $category_id = (int)$_POST["category_id"];
    } else {
        $errors['category_id'] = "Valid category is required";
    }

    // If there are no validation errors, proceed with creating the product
    if (empty($errors)) {
        $data = [
            'product_name' => $product_name,
            'category_id' => $category_id,
            'price' => $price,
            'stock' => $stock
        ];
        if ($productController->update($id, $data)) {
            echo "<script>alert('Product added successfully!')</script>";
            header("Location: ../index.php");
            exit();
        } else {
            echo "<script>alert('Failed to add product!')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-5">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Update Product</h2>
            <a href="../index.php" class="btn btn-secondary">Back to Product List</a>
        </div>

        <!-- Form Section -->
        <?php if (!empty($products)) : ?>
            <form action="" method="POST" class="bg-white p-4 rounded shadow-sm">
                <input type="hidden" name="id" value="<?php echo $products['id']; ?>">

                <!-- Product Name -->
                <div class="mb-3">
                    <label for="product_name" class="form-label">Product Name</label>
                    <input type="text" id="product_name" name="product_name" class="form-control" 
                        value="<?php echo htmlspecialchars($products['product_name']); ?>" required>
                </div>

                <!-- Category -->
                <div class="mb-3">
                    <label for="category_id" class="form-label">Category</label>
                    <select id="category_id" name="category_id" class="form-select" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $category) : ?>
                            <option value="<?= $category['id'] ?>"
                                <?= ($category['id'] == $products['category_id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($category['category_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Price -->
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" id="price" name="price" step="0.01" class="form-control" 
                        value="<?php echo $products['price']; ?>" required>
                </div>

                <!-- Stock -->
                <div class="mb-3">
                    <label for="stock" class="form-label">Stock</label>
                    <input type="number" id="stock" name="stock" class="form-control" 
                        value="<?php echo $products['stock']; ?>" required>
                </div>

                <!-- Submit Button -->
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Update Product</button>
                </div>
            </form>
        <?php else : ?>
            <p class="text-danger">Data not found.</p>
        <?php endif; ?>
    </div>
</body>

</html>
