<?php
require(__DIR__ . '/../Config/init.php');
class CategoryController
{
    private $categoryModel;

    public function __construct()
    {
        $this->categoryModel = new Category();
    }

    public function index() 
    {
        $categories = $this->categoryModel->getAllCategories();
        return $categories;
    }
    public function create($data)
    {
        try {
            $this->categoryModel->createCategory($data);
            return true;
        } catch (PDOException $e) {
            die ("Error:" . $e->getMessage());
        }
    }

    public function show($id) 
    {
        $categories = $this->categoryModel->getCategoriesById($id);
        return $categories;
    }

    public function update($id, $data)
    {
        try {
            $this->categoryModel->updateCategory($id, $data);
            return true;
            
        } catch (PDOException $e) {
            die('Error getting category:' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        $this->categoryModel->deleteCategory($id);

        $category = $category = $this->categoryModel->getCategoriesById($id);
        return $category === null || empty($category);
        header("Location: ../../category.php");
        exit();
    }
    public function restore() 
    {
        $this->categoryModel->restoreCategory();
        
    }
}


?>